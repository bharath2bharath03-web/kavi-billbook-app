KAVI PHONE KADAI - ANDROID BILL BOOK APP
========================================

HOW TO GET YOUR INSTALLABLE .APK FILE (2 EASY OPTIONS):

OPTION 1: Free Cloud Build via GitHub (No Android Studio needed - ~2 minutes)
1. Create a free repository on github.com (e.g. kavi-billbook-app).
2. Extract this ZIP and upload all files & folders (including the `.github` folder) to the repository.
3. Open the "Actions" tab in GitHub -> click "Build Kavi Phone Kadai APK".
4. Once green, download "KaviPhoneKadai-BillBook-APK" from Artifacts, unzip, and install `app-debug.apk` on your Android phone!

OPTION 2: Build locally with Android Studio
1. Extract this ZIP and open the folder in Android Studio.
2. Wait for Gradle Sync to finish.
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and install.

FEATURES INCLUDED IN THE ANDROID APP:
- Embedded Kavi Phone Kadai Bill Book (works 100% offline).
- Custom Kavi Phone Kadai app icon on your home screen.
- Native Android Print / Save as PDF support.
- Native WhatsApp Share (opens WhatsApp directly).
- Native Export / Share JSON backup & Import backup.
- Google Sheets Cloud Sync support.
- Bills are stored inside the app's own storage (clearing Chrome history will NOT delete your bills!).
